.    Path: './config/config.js'
    'use strict'

    const config = {
        ip: '127.0.0.1',
        port: process.env.PORT || 3000
    }

    module.exports = config
# Notes App with Nodejs, Express and Mysql

Aplicación justo como esta en Producción

-Para BD, importar database/db.sql
-Para iniciarlo, dentro de la carpeta "src", ejecutar el comando "node index.js"
-crear usuario gps con contraseña root con contraseña abcd1234 (o crear un usuario y modificar el archivo key.js con esa información) y darle privilegios sobre la tabla bd (en mysql)
-ingresar a localhost:3000 y a continuación seleccionar "registrar" para dar de alta un usuario
-ingresar al portal con el usuario creado
-seleccionar la opción "ubicación" y seleccionar una unidad
-en la pantalla, al final de la misma, dar click en "geolocation"